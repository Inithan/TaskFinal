package com.customer.tcs.controller;

import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TokenController {

	
	@GetMapping("/getToken")
	public OAuth2AuthorizedClient getToken(@RegisteredOAuth2AuthorizedClient("articles-client-authorization-code") OAuth2AuthorizedClient authorizedClient){
	
		System.out.println("Instant Access TOKEN:  "+ authorizedClient.getAccessToken().getTokenValue());
		System.out.println("Instant Refresh TOKEN:  "+ authorizedClient.getRefreshToken().getTokenValue());
		return authorizedClient;
	}
}
