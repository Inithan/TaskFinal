package com.customer.tcs.entity;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "issuer")
public class Issuer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "issuegen")
	@SequenceGenerator(name = "issuegen", sequenceName = "issuer_seq", allocationSize = 1)
	private int isbn;
	private int cust_Id;
	private int no_Of_Copies;
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public int getCust_Id() {
		return cust_Id;
	}
	public void setCust_Id(int cust_Id) {
		this.cust_Id = cust_Id;
	}
	public int getNo_Of_Copies() {
		return no_Of_Copies;
	}
	public void setNo_Of_Copies(int no_Of_Copies) {
		this.no_Of_Copies = no_Of_Copies;
	}
	@Override
	public int hashCode() {
		return Objects.hash(cust_Id, isbn, no_Of_Copies);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Issuer other = (Issuer) obj;
		return cust_Id == other.cust_Id && isbn == other.isbn && no_Of_Copies == other.no_Of_Copies;
	}
	public Issuer(int isbn, int cust_Id, int no_Of_Copies) {
		super();
		this.isbn = isbn;
		this.cust_Id = cust_Id;
		this.no_Of_Copies = no_Of_Copies;
	}
	public Issuer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Issuer [isbn=" + isbn + ", cust_Id=" + cust_Id + ", no_Of_Copies=" + no_Of_Copies + "]";
	}

	
	
}
