package com.customer.tcs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.customer.tcs.entity.Issuer;
import com.customer.tcs.service.IssuerService;

@RestController
@RequestMapping("/issuer")
public class IssuerController {

	@Autowired
	public IssuerService issuerService;
	
	
	@GetMapping("/fetchBookDetails/{id}")
	public Issuer fetchBookDetails(@PathVariable int id) {		
		return issuerService.fetchBookDetails(id);
	}
	
	@GetMapping("/issueBookUpdate/{isbn}/{cust_Id}/{no_Of_Copies}")
	public Issuer issueBook(@PathVariable int isbn, @PathVariable int cust_Id, @PathVariable int no_Of_Copies) {		
		return issuerService.issueBook(isbn, cust_Id, no_Of_Copies);
	}
	
	@GetMapping("/cancelBookReturn/{isbn}/{cust_Id}/{no_Of_Copies}")
	public Issuer cancelBookReturn(@PathVariable int isbn, @PathVariable int cust_Id, @PathVariable int no_Of_Copies) {		
		return issuerService.cancelBookReturn(isbn, cust_Id, no_Of_Copies);
	}
	
	
}
