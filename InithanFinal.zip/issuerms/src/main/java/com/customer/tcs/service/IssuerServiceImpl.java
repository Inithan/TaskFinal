package com.customer.tcs.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.customer.tcs.entity.Book;
import com.customer.tcs.entity.Issuer;
import com.customer.tcs.repository.IssuerRepository;

@Service
public class IssuerServiceImpl implements IssuerService{
	
	@Autowired
	public RestTemplate resttemplate;
	
	@Autowired
	public IssuerRepository issuerRepo;
	
	@Override
	public Issuer fetchBookDetails(int id) {
		 Book book = resttemplate.getForObject("http://BOOKMS-SERVICE/book/fetchBook/"+id, Book.class);
		 Issuer issuer = new Issuer();
			 issuer.setIsbn(id);
			 issuer.setNo_Of_Copies(book.getTotal_Copies()-book.getIssued_Copies());
		return issuer;
	}

	@Override
	public Issuer issueBook(int isbn, int cust_Id, int no_Of_Copies) {
		 
		 Book book = resttemplate.getForObject("http://BOOKMS-SERVICE/book/fetchBook/"+isbn, Book.class);
		 Issuer issuer = new Issuer();
			 issuer.setCust_Id(cust_Id);
			 issuer.setIsbn(isbn);
		 
		if(no_Of_Copies<=(book.getTotal_Copies()-book.getIssued_Copies())) {

				 	book.setIssued_Copies(book.getIssued_Copies()+no_Of_Copies);
				 	
				 resttemplate.postForObject("http://BOOKMS-SERVICE/book/addBook", book , Book.class);
					 issuer.setNo_Of_Copies(no_Of_Copies);
				 issuerRepo.saveAndFlush(issuer);
		}else {issuer.setNo_Of_Copies(0);}
		return issuer;
	}

	@Override
	public Issuer cancelBookReturn(int isbn, int cust_Id, int no_Of_Copies) {
		
		 Book book = resttemplate.getForObject("http://BOOKMS-SERVICE/book/fetchBook/"+isbn, Book.class);
		 
		 Issuer issuer = new Issuer();
		 issuer.setCust_Id(cust_Id);
		 issuer.setIsbn(isbn);
		 
		 Optional<Issuer> issuedBook = issuerRepo.findById(issuer.getCust_Id());
			if(no_Of_Copies<=(issuedBook.get().getNo_Of_Copies())) {

					 	book.setIssued_Copies(book.getIssued_Copies()-issuer.getNo_Of_Copies());
					 	
					 resttemplate.postForObject("http://BOOKMS-SERVICE/book/addBook", book , Book.class);
					 issuer.setNo_Of_Copies(no_Of_Copies);
					 issuerRepo.saveAndFlush(issuer);
			}else {issuer.setNo_Of_Copies(0);}
			return issuer;
	}

}
