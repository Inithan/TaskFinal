package com.customer.tcs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.customer.tcs.entity.Issuer;

@Repository
public interface IssuerRepository extends JpaRepository<Issuer, Integer> {

}
