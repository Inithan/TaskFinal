package com.customer.tcs.service;

import com.customer.tcs.entity.Issuer;

public interface IssuerService {

	Issuer fetchBookDetails(int id);

	Issuer issueBook(int isbn, int cust_Id, int no_Of_Copies);

	Issuer cancelBookReturn(int isbn, int cust_Id, int no_Of_Copies);

}
