CREATE TABLE issuer (
    isbn int NOT NULL,
    cust_Id INT PRIMARY KEY,
    no_Of_Copies INT NOT NULL
);

commit;
create sequence issuer_seq start with 1 maxvalue 999;
commit;

INSERT INTO issuer (isbn, cust_Id, no_Of_Copies)
VALUES (1000, 1001, 2);

INSERT INTO issuer (isbn, cust_Id, no_Of_Copies)
VALUES (2000, 1002, 1);

INSERT INTO issuer (isbn, cust_Id, no_Of_Copies)
VALUES (3000, 1003, 3);

INSERT INTO issuer (isbn, cust_Id, no_Of_Copies)
VALUES (4000, 1004, 1);

INSERT INTO issuer (isbn, cust_Id, no_Of_Copies)
VALUES (1, 1005, 2);

commit;