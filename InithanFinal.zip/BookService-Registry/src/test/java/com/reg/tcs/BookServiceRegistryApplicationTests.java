package com.reg.tcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookServiceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
