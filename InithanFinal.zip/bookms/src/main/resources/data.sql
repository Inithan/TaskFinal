CREATE TABLE book (
    isbn INT PRIMARY KEY,
    title VARCHAR(255),
    published_Date DATE,
    total_Copies INT,
    issued_Copies INT,
    author VARCHAR(255)
);

commit;

INSERT INTO book (isbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (1000, 'The Adventures of SQL', '2022-01-15', 100, 20, 'John Doe');
INSERT INTO book (isbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (2000, 'Database Chronicles', '2022-02-20', 150, 30, 'Jane Smith');
INSERT INTO book (isbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (3000, 'SQL Mastery', '2022-03-10', 80, 10, 'Bob Johnson');
INSERT INTO book (isbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (4000, 'Data Wonderland', '2022-04-05', 120, 25, 'Alice Davis');
INSERT INTO book (isbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (5000, 'Queries Unleashed', '2022-05-12', 200, 40, 'Charlie Brown');

commit;
create sequence book_seq start with 1 maxvalue 999;
commit;
create sequence book1_seq start with 1 maxvalue 999;
commit;
create sequence book2_seq start with 1 maxvalue 999;
commit;
