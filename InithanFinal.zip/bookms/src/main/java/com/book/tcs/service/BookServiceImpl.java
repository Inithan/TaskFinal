package com.book.tcs.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.tcs.entity.Book;
import com.book.tcs.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	public BookRepository bookrepo;
	
	
	@Override
	public Optional<Book> fetchBook(Integer id) {
		return bookrepo.findById(id);
	}
	
	@Override
	public Book addBook(Book book) {
		return bookrepo.save(book);
	}

	@Override
	public Book editBook(Book book) {
		return bookrepo.save(book);
	}

	@Override
	public String deleteBook(Integer id) {
		bookrepo.deleteById(id);
		return "Deleted the book ID:  "+id;
	}



}
