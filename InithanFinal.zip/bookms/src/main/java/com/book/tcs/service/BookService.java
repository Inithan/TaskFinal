package com.book.tcs.service;

import java.util.Optional;

import com.book.tcs.entity.Book;

public interface BookService {

	Optional<Book> fetchBook(Integer id);

	Book addBook(Book book);

	Book editBook(Book book);

	String deleteBook(Integer id);
	
}
