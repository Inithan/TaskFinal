package com.book.tcs.entity;

import java.sql.Date;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;


@Entity
@Table(name = "book")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bookgen")
	@SequenceGenerator(name = "bookgen", sequenceName = "book_seq", allocationSize = 1)
    private int isbn;
    private String title;
    private Date published_Date;
    private int total_Copies;
    private int issued_Copies;
    private String author;
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getPublished_Date() {
		return published_Date;
	}
	public void setPublished_Date(Date published_Date) {
		this.published_Date = published_Date;
	}
	public int getTotal_Copies() {
		return total_Copies;
	}
	public void setTotal_Copies(int total_Copies) {
		this.total_Copies = total_Copies;
	}
	public int getIssued_Copies() {
		return issued_Copies;
	}
	public void setIssued_Copies(int issued_Copies) {
		this.issued_Copies = issued_Copies;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	@Override
	public int hashCode() {
		return Objects.hash(author, isbn, issued_Copies, published_Date, title, total_Copies);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(author, other.author) && isbn == other.isbn && issued_Copies == other.issued_Copies
				&& Objects.equals(published_Date, other.published_Date) && Objects.equals(title, other.title)
				&& total_Copies == other.total_Copies;
	}
	public Book(int isbn, String title, Date published_Date, int total_Copies, int issued_Copies, String author) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.published_Date = published_Date;
		this.total_Copies = total_Copies;
		this.issued_Copies = issued_Copies;
		this.author = author;
	}
	public Book() {
		super();
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", published_Date=" + published_Date + ", total_Copies="
				+ total_Copies + ", issued_Copies=" + issued_Copies + ", author=" + author + "]";
	}
	
    
    
}
