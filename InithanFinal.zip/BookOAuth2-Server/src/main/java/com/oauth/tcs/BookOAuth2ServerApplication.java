package com.oauth.tcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BookOAuth2ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookOAuth2ServerApplication.class, args);
	}

}
